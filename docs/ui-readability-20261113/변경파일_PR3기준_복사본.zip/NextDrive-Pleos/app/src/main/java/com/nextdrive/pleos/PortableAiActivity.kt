package com.nextdrive.pleos

import android.app.Activity
import android.content.res.Configuration
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.WindowManager
import android.widget.*
import com.nextdrive.pleos.ai.*
import com.nextdrive.pleos.data.SqliteIssueRepository
import com.nextdrive.pleos.model.VehicleIssue
import com.nextdrive.pleos.ai.auth.*
import com.nextdrive.pleos.analytics.*
import com.nextdrive.pleos.safety.*
import com.nextdrive.pleos.ui.*
import com.nextdrive.pleos.vehicle.*
import org.json.JSONObject
import java.util.concurrent.Executors

/** First-use account/device/consent flow. No common token, vehicle writes or automatic login. */
class PortableAiActivity:Activity(){
    private lateinit var gate:CarSafetyGate
    private lateinit var ui:CaritdaComponents
    private lateinit var body:LinearLayout
    private lateinit var shell:LinearLayout
    private lateinit var status:TextView
    private lateinit var email:EditText
    private lateinit var password:EditText
    private val worker=Executors.newSingleThreadExecutor()
    @Volatile private var visible=false
    @Volatile private var generation=0
    @Volatile private var loadGeneration=0
    private var busy=false
    private var analysis:VehicleAnalysis?=null
    private var issue:VehicleIssue?=null
    private val issueMode get()=intent.hasExtra("issue_id")
    private val issueId get()=intent.getStringExtra("issue_id").orEmpty()
    private val consentVersion get()=if(issueMode)IssueExplanation.CONSENT else PortableAnalysis.CONSENT
    private var excerpt:String?=null
    private var excerptInput:EditText?=null
    private var client:PortableAiClient?=null
    private var activeStore:PortableAiStore?=null
    private var stopObserving:(()->Unit)?=null
    private var autoConsumed=false
    private var loadedSubject:String?=null
    private val session by lazy{FirebasePortableSession(this) as PortableSession}
    private var message="저장된 충전량을 확인하고 있어요."
    private var resultText=""
    private var resultOrigin=""
    private var accountDetails=false
    private var reauthOpen=false
    private var issueResult:IssueAnalysisService.Result?=null
    private val spoken by lazy{com.nextdrive.pleos.integration.SpeechOutput(this){allowed()}}
    private val playback by lazy{com.nextdrive.pleos.integration.ExplanationPlayback({allowed()},
        {text,done,changed->spoken.speak(text,done,changed)},{spoken.stop()})}
    private var vehiclePanels=emptyList<Pair<String,Snapshot>>()
    private var vehicleDetails=false
    private val fixturePrefix by lazy{intent.getStringExtra("validation_fixture")?.takeIf{
        packageName=="com.nextdrive.pleos.validation"&&Regex("gleo-ui-[a-f0-9-]{36}").matches(it)
    }}
    private val fixtureIssueDb by lazy{intent.getStringExtra("validation_issue_db")?.takeIf{
        packageName=="com.nextdrive.pleos.validation"&&Regex("issue-ai-fixture-[a-f0-9-]{36}\\.db").matches(it)
    }}
    private var previewOpen=false
    private var consentMore=false
    private var usageRefreshAttempted=false
    override fun onCreate(saved:Bundle?){super.onCreate(saved)
        accountDetails=intent.getBooleanExtra("account_reauth",false);reauthOpen=accountDetails
        autoConsumed=saved?.getBoolean("auto_consumed")?:false
        excerpt=saved?.getString("issue_excerpt")
        previewOpen=saved?.getBoolean("preview_open")?:intent.getBooleanExtra("issue_after_save",false)
        usageRefreshAttempted=saved?.getBoolean("usage_refreshed")?:false
        vehicleDetails=saved?.getBoolean("vehicle_details")?:false
        accountDetails=saved?.getBoolean("account_details")?:intent.getBooleanExtra("account_reauth",false)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        val dark=CaritdaTheme.dark(this,fixturePrefix)
        ui=CaritdaComponents(this,CaritdaPalette.of(dark))
        val root=ui.column().apply{setBackgroundColor(ui.colors.background);setPadding(ui.dp(24),ui.dp(12),ui.dp(24),ui.dp(12))};shell=root
        setContentView(CaritdaPage(this,root).apply{setBackgroundColor(ui.colors.background)})
        status=ui.text("",22).apply{tag="portable_status";accessibilityLiveRegion=View.ACCESSIBILITY_LIVE_REGION_POLITE}
        body=ui.column();aiChrome()
        root.addOnLayoutChangeListener{_,l,t,r,b,oldL,oldT,oldR,oldB->if(oldR>oldL&&(r-l!=oldR-oldL||(b-t!=oldB-oldT&&currentFocus !is EditText)))root.post{
            render()
        }}
        gate=CarSafetyGate(this){if(it!=EditingState.ALLOWED){playback.cancel();cancelWork();if(::password.isInitialized)password.text.clear()};render()}
        FirebaseSessionProvider.prepare(this);message="저장된 충전량을 확인하고 있어요.";render()
    }
    private fun allowed()=visible&&::gate.isInitialized&&gate.state==EditingState.ALLOWED
    /** Keeps the body reachable in short windows and with large system text; never covers OS UI. */
    private fun aiChrome(){
        val oldY=shell.findViewWithTag<ScrollView>("portable_scroll")?.scrollY?:0
        (body.parent as? android.view.ViewGroup)?.removeView(body)
        (status.parent as? android.view.ViewGroup)?.removeView(status)
        shell.removeAllViews();shell.setBackgroundColor(ui.colors.background);status.setTextColor(ui.colors.text)
        val width=if(shell.width>0)shell.width/resources.displayMetrics.density else resources.configuration.screenWidthDp.toFloat()
        val height=if(shell.height>0)shell.height/resources.displayMetrics.density else resources.configuration.screenHeightDp.toFloat()
        val inset=if(width<600)18 else if(width<840)24 else 32
        shell.setPadding(ui.dp(inset),ui.dp(8),ui.dp(inset),ui.dp(8))
        val short=height<480||resources.configuration.fontScale>=1.5f
        val content=if(short)ui.column()else shell
        if(packageName.endsWith(".validation"))content.addView(ui.text("검증 전용 · TEST",20,true))
        content.addView(aiHeader());content.addView(status)
        val scroll=ScrollView(this).apply{tag="portable_scroll";isFillViewport=true}
        if(short){content.addView(body);scroll.addView(content)}else scroll.addView(body)
        shell.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));scroll.post{scroll.scrollTo(0,oldY)}
    }
    private fun aiHeader():LinearLayout {
        val width=if(::shell.isInitialized&&shell.width>0)shell.width/resources.displayMetrics.density else resources.configuration.screenWidthDp.toFloat()
        val back=ui.action("이전","portable_back",ActionStyle.QUIET,true,if(width<600)null else HmiIcon.BACK){finish()}
        val home=ui.action("홈","portable_home",ActionStyle.QUIET,true,if(width<600)null else HmiIcon.HOME){
            setResult(RESULT_OK,android.content.Intent().putExtra("caritda_home",true))
            if(callingActivity==null){
                val target=android.content.Intent(this,MainActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP or android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("caritda_home",true)
                if(packageName=="com.nextdrive.pleos.validation")target.putExtra("validation_fixture",fixturePrefix?:"gleo-ui-"+java.util.UUID.randomUUID())
                startActivity(target)
            }
            finish()
        }
        return ui.screenHeader(if(issueMode)"AI 문제 설명"else"충전량 AI 설명",false,listOf(back,home),width)
    }
    private fun storeName(subject:String)=if(issueMode)"portable-issue-v1-$subject"else"portable-ai-v2-$subject"
    private fun issueJob()=issue?.let{IssueExplanation.jobKey(it)}
    private fun jobState():JSONObject {val s=state();return if(issueMode)s.optJSONObject("jobs")?.optJSONObject(issueJob().orEmpty())?:JSONObject()else s}
    private fun ready()=if(issueMode)issue!=null else analysis?.latest!=null
    private fun selectedRecord():VehicleIssue? {
        // Instrumentation may supply only a unique validation fixture DB; ordinary app ignores it.
        val name=fixturePrefix?.let{it+".db"}?:fixtureIssueDb?:"caritda_v01.db"
        return SqliteIssueRepository(this,name).use{it.issue(issueId)}
    }
    private fun restoreExcerpt(){
        if(!issueMode||excerpt!=null||issue==null)return
        runCatching{val job=jobState();if(job.has("excerpt")){excerpt=job.getString("excerpt");excerptInput=null}}
    }
    private fun persistExcerpt(){
        excerptInput?.let{excerpt=it.text.toString()}
        if(!issueMode||busy||issue==null||excerpt==null)return
        runCatching{
            val subject=session.subject?:return
            val store=PortableAiStore(this,storeName(subject));val root=store.read()
            if(root.optString("consent")!=consentVersion)return
            val jobs=root.optJSONObject("jobs")?:JSONObject().also{root.put("jobs",it)}
            val key=issueJob()?:return;val job=jobs.optJSONObject(key)?:JSONObject().also{jobs.put(key,it)}
            if(job.optString("excerpt")!=excerpt){job.put("excerpt",excerpt).put("record",issueId);store.write(root)}
        }
    }
    private fun loadVehicleContext():List<Pair<String,Snapshot>> = runCatching{
        // Read already committed local snapshots only. No SDK fetch and no relay payload input.
        val name=fixturePrefix?.let{it+"-snapshots.db"}?:fixtureIssueDb?.let{it.removeSuffix(".db")+"-snapshots.db"}?:"caritda-snapshots.db"
        SnapshotStore(this,name).use{store->
            val linked=store.linked(issueId);val latest=store.latest()
            buildList{
                linked?.let{add("이 기록에 함께 저장한 차량 정보" to it)}
                latest?.takeIf{it.id!=linked?.id}?.let{add("최근에 불러온 차량 정보 · 증상에 연결되지 않은 참고값" to it)}
            }
        }
    }.getOrDefault(emptyList())
    private fun vehicleContextText(s:Snapshot):String=buildString{
        for(kind in listOf("EV_SOC","ODOMETER","FUEL_PERCENT")){
            val(attempt,valid)=VehicleUi.values(s,kind)
            val card=VehiclePresentation.card(kind,attempt,valid,System.currentTimeMillis())
            appendLine("${VehicleUi.name(kind)} · ${card.value}\n${card.time}")
            if(card.attempt.isNotBlank())appendLine(card.attempt)
            appendLine(card.source)
        }
        append("앱이 불러온 시점의 정보예요. 증상 당시 값이나 원인을 뜻하지 않아요. AI에 보내지 않아요.")
    }
    private fun speakResult(){
        if(!allowed()||busy||resultText.isBlank())return
        playback.play(resultText){text->message=text;status.text=text;if(!playback.busy)body.post{if(visible)render()}}
        render()
    }
    private fun state():JSONObject=session.subject?.let{PortableAiStore(this,storeName(it)).read()}?:JSONObject()
    private fun consentReady()=runCatching{state().optString("consent")==consentVersion}.getOrDefault(false)
    private fun cancelWork(){generation++;client?.cancel();client=null;activeStore?.invalidate();activeStore=null;busy=false}
    private fun render(){if(!::body.isInitialized)return
        val draftEmail=if(::email.isInitialized)email.text.toString()else""
        restoreExcerpt()
        excerptInput?.let{excerpt=it.text.toString()};excerptInput=null
        aiChrome()
        body.removeAllViews()
        val pageBody=body;val requestPane=ui.card();val resultPane=ui.card()
        val width=if(shell.width>0)shell.width/resources.displayMetrics.density else resources.configuration.screenWidthDp.toFloat()
        pageBody.addView(ui.text("원인을 맞히는 게 아니라, 다음에 볼 곳을 알려 드려요.",28,true))
        pageBody.addView(ui.twoPane(requestPane,resultPane,width>=840&&resources.configuration.fontScale<1.5f))
        val body=requestPane
        body.addView(ui.sectionTitle("AI에게 보낼 내용",HmiIcon.RECORD))
        if(issueMode&&intent.getBooleanExtra("issue_after_save",false))body.addView(ui.state("기록을 저장했어요", "증상을 다시 입력할 필요 없어요. 전송 내용을 확인한 뒤 아래에서 AI 설명을 요청해 주세요.").apply{tag="portable_saved_record"})
        body.addView(ui.text(if(issueMode)"선택한 증상 한 건의 가능한 원인과 확인할 일을 설명해요. 확정 진단은 아니에요."else"차량에서 받은 충전량 기록만 설명해요. 고장 진단이나 운행 안전 판단은 하지 않아요.",22))
        if(issueMode&&issue!=null){
            body.addView(ui.text("전송할 증상 · ${issue!!.type.label}",24,true))
            val pendingText=runCatching{JSONObject(jobState().getJSONObject("pending").getString("payload")).getString("situation")}.getOrNull()
            val field=EditText(this).apply{tag="issue_ai_excerpt";setText(pendingText?:excerpt?:issue!!.situation);textSize=28f;minLines=2;setTextColor(ui.colors.text);isSaveEnabled=false;isEnabled=allowed()&&!busy&&pendingText==null;inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE}
            excerptInput=field;body.addView(field)
            body.addView(ui.text("이름과 전화번호는 지워 주세요. 여기서 고쳐도 원래 기록은 그대로예요.",20))
            if(vehiclePanels.isNotEmpty()){
                body.addView(ui.text("이 휴대폰에서만 보는 차 정보 (AI에 안 보내요)",20).apply{tag="portable_vehicle_context"})
                body.addView(ui.expandable("함께 볼 차량 정보 자세히","portable_vehicle_details",vehicleDetails,allowed()){vehicleDetails=!vehicleDetails;render()})
                if(vehicleDetails)vehiclePanels.forEach{(title,snapshot)->body.addView(ui.state(title,vehicleContextText(snapshot)))}
            }
        }
        if(!allowed())body.addView(ui.state("안전하게 정차한 뒤 이용해 주세요.","입력 허용 상태가 확인돼야 로그인·AI 요청을 할 수 있어요."))
        status.text=message
        if(!allowed()){status.text="현재는 AI 조작을 할 수 없어요. 안전하게 정차한 뒤 확인해 주세요.";return}
        body.addView(ui.action(if(previewOpen)"전송 내용 접기"else"전송 범위 자세히","portable_preview",ActionStyle.QUIET,allowed()&&!busy&&ready(),HmiIcon.RECORD){previewOpen=!previewOpen;render()})
        if(previewOpen&&ready()){
            val preview=runCatching{AiRequestUi.summary(if(issueMode)IssueExplanation.payload(issue!!,excerpt?:issue!!.situation)else PortableAnalysis.payload(analysis!!))}.getOrElse{(it as? PortableFailure)?.displayMessage()?:"전송할 내용을 확인해 주세요."}
            body.addView(ui.state("전송할 내용 · 원래 기록은 바뀌지 않아요",preview).apply{tag="portable_payload_preview"})
        }
        val signed=session.signedIn
        fun input(tagName:String,label:String,type:Int)=EditText(this).apply{tag=tagName;hint=label;inputType=type;textSize=28f;minHeight=ui.dp(76);setTextColor(ui.colors.text);isSaveEnabled=false;importantForAutofill=View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS}
        if(!signed){
            body.addView(ui.text("처음 한 번만 로그인해 주세요. 운전자 이름과는 다른 계정이에요. 이메일과 비밀번호는 로그인 확인용으로 Firebase(구글의 로그인 서비스)에 보내져요.",22))
            email=input("portable_email","이메일",InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS).apply{setText(draftEmail)};body.addView(email)
            password=input("portable_password","비밀번호",InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD);body.addView(password)
            body.addView(ui.action("로그인","portable_login",ActionStyle.PRIMARY,allowed()&&!busy&&!FirebaseSessionProvider.busy&&FirebaseSessionProvider.initialized,HmiIcon.PERSON){
                if(!allowed()||busy)return@action
                val e=email.text.toString();val p=password.text.toString();password.text.clear();val run=generation
                message="로그인하고 있어요.";FirebaseSessionProvider.signIn(e,p){r->if(visible&&run==generation){message=if(r.signedIn)"로그인됐어요. 처음에는 전송 안내를 확인해 주세요."else PortableFailure(r.code).displayMessage();render()}}
            });return
        }
        val cached=runCatching{jobState().optJSONObject("last")}.getOrNull()
        if(resultText.isBlank()&&cached!=null){
            if(issueMode){issueResult=runCatching{IssueAnalysisService.saved(cached)}.getOrNull();resultText=issueResult?.text.orEmpty()}
            else resultText=runCatching{val answer=cached.getJSONObject("answer");PortableAnalysis.validate(answer,cached.getString("payload"),answer.getString("operation_id"))}.getOrDefault("")
            if(resultText.isNotBlank())resultOrigin="저장된 AI 설명 · 새 요청 없음"
        }
        if(resultText.isNotBlank()){
            resultPane.addView(ui.action("이 설명 음성으로 듣기","portable_speak",ActionStyle.SECONDARY,allowed()&&!busy&&!playback.busy){speakResult()})
            if(playback.busy)resultPane.addView(ui.action("음성 안내 멈추기","portable_speak_stop",ActionStyle.QUIET,allowed()){playback.cancel();message="음성 안내를 멈췄어요.";render()})
            resultPane.addView(ui.column().apply{
                tag="portable_model_result"
                addView(ui.sectionTitle(issueResult?.title?:resultOrigin.ifBlank{"AI 점검 참고"}))
                addView(ui.text(resultText,22,secondary=true))
            })
            issueResult?.let{resultPane.addView(ui.state("이 설명에 사용한 증상",it.situation).apply{tag="portable_result_input"})}
        }
        if(resultText.isBlank())resultPane.addView(ui.state("설명을 생성하기 전이에요.","기록은 이미 저장돼요. 전송할 내용을 확인하고 새 설명을 선택해 주세요."))
        val a=analysis
        if(!issueMode&&a?.latest!=null)body.addView(ui.metric("설명할 충전량",VehicleAnalysis.fmt(a.latest!!.number)+" %","최근 하루 · ${a.points.size}건",if(a.latest!!.ref.value.source==ObservationSource.PLEOS_EMULATOR_SDK)"Pleos 에뮬레이터에서 받은 값이에요."else"차량 SDK에서 받은 값이에요.","portable_soc",HmiIcon.BATTERY))
        if(!consentReady()){
            autoConsumed=true // First-use login/registration never silently calls the model.
            body.addView(ui.state("처음 한 번만 동의해 주세요.",if(issueMode)"· 보내는 것: 고른 증상 한 건의 종류와 내용\n· 보내는 곳: Google Gemini (중계 서버를 거쳐요)\n· 안 보내는 것: 작성자, 메모, 시간, 차량값, 다른 기록\n· 보관: 설명은 이 기기에 암호화해 저장하고, 서버 결과는 하루 뒤 지워요.\n· 알아 두세요: 이름이나 연락처는 빼 주세요. AI가 틀릴 수 있어요. 동의는 언제든 철회할 수 있어요."else"· 보내는 것: 충전량의 최근값, 최소, 최대, 평균, 변화량\n· 보내는 곳: Google Gemini (중계 서버를 거쳐요)\n· 안 보내는 것: 이름, 차대번호, 위치, 증상 원문\n· 알아 두세요: 동의는 언제든 철회할 수 있어요.").apply{tag="portable_consent_short"})
            body.addView(ui.expandable("동의 내용 자세히 보기","portable_consent_more",consentMore,!busy){consentMore=!consentMore;render()})
            if(consentMore)body.addView(ui.state("동의 내용 전체",if(issueMode)"선택한 한 건의 증상 종류와 위 본문을 Cloudflare 중계와 Google Gemini로 보내요. 작성자·메모·시간·차량값·다른 기록은 보내지 않아요. 개인 이름 등이 본문에 있으면 먼저 빼 주세요. 설명은 이 기기에 암호화해 저장하고, 서버 결과는 하루 뒤 삭제해요. AI가 틀릴 수 있어요. 이후 선택한 기록의 AI 버튼을 누르면 같은 범위로 요청하며, 동의는 철회할 수 있어요."else"충전량의 최근값·최소·최대·관측 평균·비교 가능한 변화량, 표본 수·상대 경과시간·품질 요약을 Cloudflare 중계와 Google Gemini로 보내요. 이름·VIN·위치·증상 원문·원본 DB는 보내지 않아요. 로그인 계정과 기기 서명은 중계 인증에만 사용해요. 다음 요청부터 같은 범위에 동의를 유지하며 언제든 철회할 수 있어요."))
            body.addView(ui.action("동의하고 이 기기 등록","portable_register",ActionStyle.PRIMARY,allowed()&&!busy&&ready(),HmiIcon.CHECK){sessionTask {api->api.register();"AI 이용 동의와 기기 등록을 저장했어요."}})
            body.addView(ui.action("동의하지 않고 돌아가기","portable_consent_cancel",ActionStyle.SECONDARY,!busy,HmiIcon.BACK){finish()})
        }else{
            body.addView(ui.text("AI 사용에 동의한 상태예요.",20))
            val quotaBlock=AiRequestUi.block(state().optJSONObject("usage_status"),jobState().has("pending"))
            if(quotaBlock!=null)body.addView(ui.state("새 설명 이용 안내",quotaBlock).apply{tag="portable_quota_notice"})
            body.addView(ui.action(if(jobState().has("pending"))"진행 중 요청 결과 확인"else"새로 설명 생성","portable_explain",ActionStyle.PRIMARY,allowed()&&!busy&&ready()&&quotaBlock==null,HmiIcon.RECORD){if(jobState().has("last")&&!jobState().has("pending"))android.app.AlertDialog.Builder(this).setTitle("새 설명을 생성할까요?").setMessage("새 API 요청으로 이용 한도가 차감될 수 있어요. 기존 설명은 보존해요.").setNegativeButton("취소",null).setPositiveButton("새로 생성"){_,_->requestExplanation(true)}.show()else requestExplanation(true)})
            body.addView(ui.action("AI 이용 동의 철회","portable_withdraw",ActionStyle.SECONDARY,allowed()&&!busy,HmiIcon.BACK){
                sessionTask {api->
                    val revoked=runCatching{api.revoke()}.isSuccess
                    api.withdrawLocal()
                    session.subject?.let{subject->com.nextdrive.pleos.voice.VoicePrivacy.withdrawCloud(this,subject)}
                    if(revoked)"동의를 철회했어요. 서버의 이 기기 동의와 로컬 AI 결과를 지웠어요. 이미 전송된 요청은 되돌릴 수 없어요."
                    else "이 앱의 동의를 철회했어요. 서버에는 연결하지 못했어요. 관리자에게 기기 동의 해제를 요청해 주세요. 이미 전송된 요청은 되돌릴 수 없어요."
                };resultText="";issueResult=null;playback.cancel()
            })
        }
        if(consentReady())body.addView(ui.action("오늘 AI를 몇 번 더 쓸 수 있는지 보기","portable_status_check",ActionStyle.QUIET,allowed()&&!busy,HmiIcon.CHECK){sessionTask {api->val s=api.status();AiRequestUi.quotaText(s)}})
        jobState().optJSONObject("last_failure")?.takeIf{it.optLong("at")>(cached?.optLong("saved_at")?:0)}?.let{body.addView(ui.state("새로 물어봤지만 실패했어요. 전에 받은 설명은 남아 있어요.",PortableFailure(it.optString("code")).displayMessage(),true))}
        if(issueMode){val jobs=runCatching{state().optJSONObject("jobs")}.getOrNull();jobs?.keys()?.asSequence()?.filter{it!=issueJob()}?.mapNotNull{jobs.optJSONObject(it)}?.filter{it.optString("record")==issueId}?.mapNotNull{it.optJSONObject("last")}?.forEach{old->val a=old.getJSONObject("answer");val text=runCatching{IssueExplanation.validate(a,old.getString("payload"),a.getString("operation_id"))}.getOrNull();if(text!=null)body.addView(ui.state("수정 전 기록의 AI 설명 · 현재 내용과 다를 수 있어요",text))}}
        if(cached!=null&&resultText.isBlank())body.addView(ui.action("전에 받은 AI 설명 다시 보기","portable_view_saved",ActionStyle.SECONDARY,allowed()&&!busy,HmiIcon.RECORD){playback.cancel();val a=cached.getJSONObject("answer");resultText=if(issueMode)IssueAnalysisService.saved(cached).also{issueResult=it}.text else PortableAnalysis.validate(a,cached.getString("payload"),a.getString("operation_id"));message="저장된 설명이에요. 새 요청은 하지 않았어요.";render()})
        if(resultText.isBlank()&&cached!=null){val answer=cached.getJSONObject("answer");val text=runCatching{if(issueMode)IssueExplanation.validate(answer,cached.getString("payload"),answer.getString("operation_id"))else PortableAnalysis.validate(answer,cached.getString("payload"),answer.getString("operation_id"))}.getOrNull();if(text!=null)body.addView(ui.state("이전에 받은 AI 설명 · 현재 상태 판정 아님",text).apply{tag="portable_cached_result"})}
        body.addView(ui.action("로그아웃","portable_logout",ActionStyle.QUIET,allowed()&&!busy,HmiIcon.BACK){playback.cancel();cancelWork();session.subject?.let{PortableAiStore(this,storeName(it)).withdraw()};FirebaseSessionProvider.signOut();resultText="";issueResult=null;message="로그아웃했어요. 차량 기록은 그대로예요.";render()})
        val accountTags=setOf("portable_withdraw","portable_status_check","portable_logout")
        val accountViews=(0 until body.childCount).map{body.getChildAt(it)}.filter{it.tag in accountTags}
        accountViews.forEach{body.removeView(it)}
        body.addView(ui.expandable("계정·이용 정보","portable_account_details",accountDetails,allowed()&&!busy){accountDetails=!accountDetails;render()})
        if(accountDetails){
            body.addView(ui.action("현재 계정 확인 갱신","portable_reauth_open",ActionStyle.SECONDARY,allowed()&&!busy&&!FirebaseSessionProvider.busy,HmiIcon.PERSON){reauthOpen=!reauthOpen;render()})
            if(reauthOpen){
                body.addView(ui.text("이 기기를 쓰려면 비밀번호를 한 번 더 확인해야 해요. 로그아웃되거나 전에 받은 설명이 지워지지는 않아요.",20))
                val secret=input("portable_reauth_password","현재 계정 비밀번호",InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD);body.addView(secret)
                body.addView(ui.action("이 계정으로 확인","portable_reauth_submit",ActionStyle.PRIMARY,allowed()&&!busy&&!FirebaseSessionProvider.busy){
                    if(!allowed()||busy)return@action
                    val value=secret.text.toString();secret.text.clear();val run=generation
                    FirebaseSessionProvider.reauthenticate(value){result->if(visible&&run==generation){
                        message=when(result.code){"AUTH_REAUTHENTICATED"->"현재 계정 확인을 갱신했어요. 기존 기록과 AI 설명은 그대로예요.";"AUTH_CREDENTIALS"->"비밀번호를 다시 확인해 주세요. 현재 로그인은 유지돼요.";else->PortableFailure(result.code).displayMessage()}
                        if(result.code=="AUTH_REAUTHENTICATED")reauthOpen=false
                        render()
                    }}
                })
            }
            body.addView(ui.text("로그아웃하면 이 휴대폰에 저장된 AI 설명이 지워져요. 차량 기록은 그대로예요. 동의를 취소하는 것과는 달라요.",20))
            accountViews.forEach{body.addView(it)}
        }
        val fixtureUi=fixturePrefix!=null||fixtureIssueDb!=null
        if(issueMode&&!fixtureUi&&!usageRefreshAttempted&&ready()&&consentReady()&&allowed()&&!busy&&AiRequestUi.shouldRefresh(state().optJSONObject("usage_status"))){
            usageRefreshAttempted=true;body.post{if(visible&&allowed()&&!busy)sessionTask{api->AiRequestUi.quotaText(api.status())}}
        }
    }
    private fun requestExplanation(fresh:Boolean=false){
        if(!allowed()||busy||!consentReady())return
        excerptInput?.let{excerpt=it.text.toString()}
        persistExcerpt();playback.cancel()
        var prepared:IssueAnalysisService.Result?=null
        sessionTask(work={api->
            val selected=issue
            if(issueMode){
                prepared=IssueAnalysisService.explain(api,selected?:throw PortableFailure("ISSUE_UNAVAILABLE"),excerpt?:selected.situation,fresh,::selectedRecord)
                return@sessionTask prepared!!.text
            }
            val payload=if(api.hasPending())""else PortableAnalysis.payload(analysis?:throw PortableFailure("NO_VALID_SOC"))
            val answer=api.explain(payload,fresh)
            val explanation=answer.getString("explanation")
            val source=answer.getJSONObject("facts").getJSONObject("facts")
            "최근 충전량 ${VehicleAnalysis.fmt(source.getDouble("latest"))}%\n$explanation\n차량의 실제 표시와 함께 확인해 주세요.\n모델 · ${answer.getString("model")}"
        },modelResult=true,prepared={prepared})
    }
    private fun sessionTask(modelResult:Boolean=false,prepared:(()->IssueAnalysisService.Result?)?=null,work:(PortableAiClient)->String){
        if(!allowed()||busy)return
        busy=true;val run=generation;message="요청을 확인하고 있어요. 중복 전송하지 않아요.";render()
        val tokenDeadline=Runnable {if(visible&&run==generation&&busy){cancelWork();message=PortableFailure("AUTH_TOKEN_TIMEOUT").displayMessage();render()}}
        val feedbackHandler=android.os.Handler(mainLooper);feedbackHandler.postDelayed(tokenDeadline,15000)
        session.acquire {uid,token,error->
            feedbackHandler.removeCallbacks(tokenDeadline)
            if(!visible||run!=generation||!allowed())return@acquire
            if(error!=null||uid==null||token==null){busy=false;message=PortableFailure(error?:"AUTH_SIGN_IN_REQUIRED").displayMessage();render();return@acquire}
            val s=PortableAiStore(this,storeName(VehicleAnalytics.id(uid)));activeStore=s
            val api=session.client(s,uid,token,allowed={visible&&run==generation&&gate.state==EditingState.ALLOWED&&session.matches(uid)},job=if(issueMode)issueJob()?:throw PortableFailure("ISSUE_UNAVAILABLE")else null,record=if(issueMode)issueId else null);client=api
            worker.execute {val result=runCatching{work(api)};runOnUiThread {
                if(visible&&run==generation){busy=false;client=null;activeStore=null;result.onSuccess{if(modelResult){issueResult=prepared?.invoke();resultText=it;resultOrigin="새로 받은 AI 설명";message="AI 설명을 받았어요. 아래에서 확인해 주세요."}else message=it}.onFailure{message=((it as? PortableFailure)?:PortableFailure("AI_REQUEST_FAILED")).displayMessage()};render()}
            }}
        }
    }
    private fun loadAnalysis(){val run=++loadGeneration;worker.execute {
        if(issueMode){val selected=runCatching{selectedRecord()}.getOrNull();val panels=if(selected!=null)loadVehicleContext()else emptyList();runOnUiThread{if(visible&&run==loadGeneration){issue=selected;vehiclePanels=panels;if(selected!=null)runCatching{val job=jobState();if(excerpt==null&&job.has("excerpt"))excerpt=job.getString("excerpt")};message=if(selected==null)"기록을 찾을 수 없어요. 이전 화면에서 다시 선택해 주세요."else"선택한 증상만 설명해요. 원래 기록은 바뀌지 않아요.";render()}};return@execute}
        val r=runCatching{val now=System.currentTimeMillis();ObservationStore(this,fixturePrefix?.let{it+"-observations.db"}?:"caritda-observations.db").use{val refs=it.analysisRefs("EV_SOC",now-86400000);VehicleAnalytics.analyze("EV_SOC",refs.takeLast(2000),now-86400000,now,truncated=refs.size>2000)}}
        runOnUiThread{if(visible&&run==loadGeneration){analysis=r.getOrNull();message=if(analysis?.latest!=null)"설명할 최근 충전량이 있어요."else"차량 정보 화면에서 최근 값을 먼저 불러와 주세요.";render()}}
    }}
    override fun onStart(){super.onStart();visible=true;loadedSubject=session.subject;stopObserving=FirebaseSessionProvider.observe {val next=session.subject;if(next!=loadedSubject){playback.cancel();cancelWork();resultText="";issueResult=null;excerpt=null;excerptInput=null;usageRefreshAttempted=false;loadedSubject=next;message=if(next==null)"계정으로 로그인해 주세요."else"로그인됐어요. AI 이용 안내를 확인해 주세요."};if(visible)render()};gate.start();loadAnalysis()}
    override fun onStop(){persistExcerpt();visible=false;playback.cancel();loadGeneration++;cancelWork();resultText="";issueResult=null;if(::password.isInitialized)password.text.clear();if(::email.isInitialized)email.text.clear();stopObserving?.invoke();stopObserving=null;gate.stop();super.onStop()}
    override fun onDestroy(){worker.shutdownNow();super.onDestroy()}
    override fun onSaveInstanceState(out:Bundle){persistExcerpt();out.putBoolean("auto_consumed",autoConsumed);out.putBoolean("preview_open",previewOpen);out.putBoolean("usage_refreshed",usageRefreshAttempted);out.putBoolean("vehicle_details",vehicleDetails);out.putBoolean("account_details",accountDetails);out.putString("issue_excerpt",excerptInput?.text?.toString()?:excerpt);super.onSaveInstanceState(out)}
}
